package com.heyproject.storyapp.core

const val BASE_URL = "https://story-api.dicoding.dev/v1/"
const val MIN_PASSWORD_LENGTH = 6